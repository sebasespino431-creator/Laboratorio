﻿nusing System;

namespace L14_Simplificado
{
    public class Libro
    {
        private string titulo, autor;
        private int anioPublicacion;
        private bool disponible;

        public Libro(string titulo, string autor, int anioPublicacion, bool disponible)
        {
            this.titulo = titulo;
            this.autor = autor;
            this.anioPublicacion = anioPublicacion;
            this.disponible = disponible;
        }

        public void MostrarInformacion()
        {
            Console.WriteLine($"Título: {titulo}, Autor: {autor}, Año: {anioPublicacion}, Disponible: {(disponible ? "Sí" : "No")}");
        }

        public void PrestarLibro()
        {
            if (disponible)
            {
                disponible = false;
                Console.WriteLine($"\"{titulo}\" prestado.");
            }
            else Console.WriteLine($"\"{titulo}\" no disponible.");
        }

        public void DevolverLibro()
        {
            if (!disponible)
            {
                disponible = true;
                Console.WriteLine($"\"{titulo}\" devuelto.");
            }
            else Console.WriteLine($"\"{titulo}\"estaba disponible.");
        }
    }

    public class Mascota
    {
        private string nombre, especie;
        private int edad;
        private bool vacunado;

        public Mascota(string nombre, string especie, int edad, bool vacunado)
        {
            this.nombre = nombre;
            this.especie = especie;
            this.edad = edad;
            this.vacunado = vacunado;
        }

        public void MostrarInformacion()
        {
            Console.WriteLine($"Nombre: {nombre}, Especie: {especie}, Edad: {edad}, Vacunado: {(vacunado ? "Sí" : "No")}");
        }

        public void Vacunar()
        {
            if (!vacunado)
            {
                vacunado = true;
                Console.WriteLine($"{nombre} vacunado.");
            }
            else Console.WriteLine($"{nombre} ya vacunado.");
        }

        public void CumplirAnios()
        {
            edad++;
            Console.WriteLine($"{nombre} tiene {edad}.");
        }
    }

    public class Estudiante
    {
        private string nombre, grado;
        private int edad;
        private decimal[] notas;

        public Estudiante(string nombre, int edad, string grado, decimal[] notas)
        {
            this.nombre = nombre;
            this.edad = edad;
            this.grado = grado;
            this.notas = new decimal[notas.Length];
            Array.Copy(notas, this.notas, notas.Length);
        }

        public decimal CalcularPromedio()
        {
            if (notas.Length == 0) return 0;
            decimal suma = 0;
            foreach (decimal n in notas) suma += n;
            return suma / notas.Length;
        }

        public void MostrarInformacion()
        {
            Console.Write($"Nombre: {nombre}, Edad: {edad}, Grado: {grado}, Notas: ");
            for (int i = 0; i < notas.Length; i++)
            {
                Console.Write(notas[i].ToString("F2"));
                if (i < notas.Length - 1) Console.Write(", ");
            }
            Console.WriteLine($", Promedio: {CalcularPromedio():F2}");
        }

        public bool Aprobar() => CalcularPromedio() >= 61;

        public void AgregarNota(decimal nuevaNota)
        {
            decimal[] nuevo = new decimal[notas.Length + 1];
            Array.Copy(notas, nuevo, notas.Length);
            nuevo[nuevo.Length - 1] = nuevaNota;
            notas = nuevo;
        }
    }

    class Program
    {
        static void Main()
        {

            Libro l1 = new Libro("Roma Victoriosa", "Estebanquito", 1967, true);
            Libro l2 = new Libro("Eso Tilin", "El pepe", 1988, false);
            l1.MostrarInformacion();
            l2.MostrarInformacion();
            l1.PrestarLibro();
            l1.MostrarInformacion();
            l2.PrestarLibro();
            l1.DevolverLibro();
            l1.MostrarInformacion();


            Mascota m1 = new Mascota("michi", "chuco", 3, false);
            Mascota m2 = new Mascota("migi", "gato", 2, true);
            m1.MostrarInformacion();
            m2.MostrarInformacion();
            m1.Vacunar();
            m1.MostrarInformacion();
            m1.CumplirAnios();
            m2.CumplirAnios();
            m1.MostrarInformacion();
            m2.MostrarInformacion();
            Estudiante e1 = new Estudiante("Emily Cruz", 16, "10°", new decimal[] { 78.5m, 82.0m, 65.5m, 90.0m });
            Estudiante e2 = new Estudiante("Ana Santizo", 17, "11°", new decimal[] { 55.0m, 60.0m, 58.5m, 70.0m });
            e1.MostrarInformacion();
            Console.WriteLine("Aprobó: " + (e1.Aprobar() ? "Sí" : "No"));
            e2.MostrarInformacion();
            Console.WriteLine("Aprobó: " + (e2.Aprobar() ? "Sí" : "No"));
            e2.AgregarNota(85.0m);
            e2.MostrarInformacion();
            Console.WriteLine("Aprobó: " + (e2.Aprobar() ? "Sí" : "No"));

            Console.ReadKey();
        }
    }
}