﻿using System;

internal class Program
{

    // Cada objeto Parcela representa una celda de la cuadrícula.
    
    class Parcela
    {
        public string siembra;           
        public int crecimientoActual;   
        public int mesesCrecimiento;     
        public double ingresos;         
        public bool regadaEsteMes;       

        // Método para asignar un cultivo a la parcela
        // Recibe el nombre del cultivo y configura todos los atributos según la tabla del proyecto
        public void sembrar(string cultivo)
        {
            siembra = cultivo;
            switch (cultivo.ToLower())
            {
                case "papa":
                    mesesCrecimiento = 2;
                    crecimientoActual = 0;
                    ingresos = 450;      // Según el enunciado: Papa = Q450
                    regadaEsteMes = false;
                    break;
                case "tomate":
                    mesesCrecimiento = 3;
                    crecimientoActual = 0;
                    ingresos = 650;
                    regadaEsteMes = false;
                    break;
                case "fresa":
                    mesesCrecimiento = 4;
                    crecimientoActual = 0;
                    ingresos = 900;
                    regadaEsteMes = false;
                    break;
                default:                // Si el cultivo no es válido, la parcela queda vacía
                    siembra = "vacia";
                    mesesCrecimiento = 0;
                    crecimientoActual = 0;
                    ingresos = 0;
                    regadaEsteMes = false;
                    break;
            }
        }
    }

   
    // Se usan para el reporte final. Son estáticos porque pertenecen al programa,
    // no a una parcela en particular. Llevan la cuenta total de siembras y cosechas
    // por cada tipo de cultivo.
    static int papasSembradas = 0, tomatesSembrados = 0, fresasSembradas = 0;
    static int papasCosechadas = 0, tomatesCosechados = 0, fresasCosechadas = 0;

  
    static void Main(string[] args)
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine("-Bienvenido a su granja virtual-");
        Console.ResetColor();

        double dineroInicial, sueldoXempleado;
        double dineroTotal = 0, totalIngresos = 0, totalEgresos = 0;
        int empleados, mesesTotales;
        int mesesSimulados = 0, riegosRealizados = 0;

        // ---------- CONFIGURACIÓN INICIAL (validada) ----------
        // Todos los datos se piden usando funciones que no permiten valores inválidos
        // (negativos, cero, texto, fuera de rango)
        dineroInicial = LeerDouble("Por favor ingrese el dinero inicial de su granja: (Q) ", 0);
        dineroTotal = dineroInicial;

        empleados = LeerEntero("Ingrese con cuantos empleados cuenta: ", 1);
        sueldoXempleado = LeerDouble("Ingrese el sueldo por empleado (mínimo Q200): ", 200);
        mesesTotales = LeerEntero("Ingrese los meses a simular: ", 1);

        int filas = LeerEntero("Ingrese filas de la cuadrícula: ", 1);
        int columnas = LeerEntero("Ingrese columnas de la cuadrícula: ", 1);

        // Crear la matriz de parcelas (estructura de datos principal)
        Parcela[,] parcelas = new Parcela[filas, columnas];
        for (int i = 0; i < filas; i++)
            for (int j = 0; j < columnas; j++)
            {
                parcelas[i, j] = new Parcela();
                parcelas[i, j].sembrar("vacia");   // Todas empiezan vacías
            }

        // ---------- BUCLE PRINCIPAL ----------
        // El programa se ejecuta mientras queden meses, haya dinero y el usuario no haya elegido Salir
        bool salir = false;
        while (mesesTotales > 0 && dineroTotal > 0 && !salir)
        {
            MostrarMenu();
            int opcion = LeerEntero("Seleccione una opción: ", 1, 5);
            salir = EjecutarOpcion(opcion, parcelas, ref dineroTotal, ref totalIngresos, ref totalEgresos,
                                   ref riegosRealizados, ref mesesSimulados, ref empleados,
                                   ref sueldoXempleado, ref mesesTotales);
        }

        // Al salir del bucle, se genera el reporte final con todas las estadísticas
        MostrarReporteFinal(dineroTotal, totalIngresos, totalEgresos, mesesSimulados,
                            riegosRealizados, parcelas);
    }



    static void MostrarMenu()
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine("\n=== MENÚ ===");
        Console.WriteLine("1. Sembrar");
        Console.WriteLine("2. Regar parcela");
        Console.WriteLine("3. Consultar parcela");
        Console.WriteLine("4. Avanzar mes");
        Console.WriteLine("5. Salir");
        Console.ResetColor();
    }

    // Ejecuta la opción seleccionada y devuelve true si se debe salir del programa
    static bool EjecutarOpcion(int opcion, Parcela[,] parcelas, ref double dineroTotal, ref double totalIngresos,
                               ref double totalEgresos, ref int riegosRealizados, ref int mesesSimulados,
                               ref int empleados, ref double sueldoXempleado, ref int mesesTotales)
    {
        switch (opcion)
        {
            case 1: Sembrar(parcelas); break;
            case 2: Regar(parcelas, ref dineroTotal, ref totalEgresos, ref riegosRealizados); break;
            case 3: ConsultarParcela(parcelas); break;
            case 4:
                AvanzarMes(parcelas, ref empleados, ref mesesSimulados, ref sueldoXempleado,
                               ref dineroTotal, ref totalIngresos, ref totalEgresos, ref mesesTotales); break;
            case 5: return true;   // Indica que se debe salir
            default:
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Opción inválida");
                Console.ResetColor();
                break;
        }
        return false;
    }

    // 1. Sembrar
    static void Sembrar(Parcela[,] parcelas)
    {
        // El usuario ingresa coordenadas base 1 (más natural), internamente restamos 1 para índice de matriz
        int f = LeerEntero($"Ingrese fila (1 a {parcelas.GetLength(0)}): ", 1, parcelas.GetLength(0)) - 1;
        int c = LeerEntero($"Ingrese columna (1 a {parcelas.GetLength(1)}): ", 1, parcelas.GetLength(1)) - 1;

        // Validación: la parcela debe estar vacía
        if (parcelas[f, c].siembra != "vacia")
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Esa parcela ya tiene siembra.");
            Console.ResetColor();
            return;
        }

        Console.Write("Ingrese tipo de siembra (papa, tomate, fresa): ");
        string cultivo = Console.ReadLine().ToLower();
        if (cultivo != "papa" && cultivo != "tomate" && cultivo != "fresa")
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Cultivo inválido.");
            Console.ResetColor();
            return;
        }

        // Sembrar y aumentar el contador correspondiente
        parcelas[f, c].sembrar(cultivo);
        if (cultivo == "papa") papasSembradas++;
        else if (cultivo == "tomate") tomatesSembrados++;
        else if (cultivo == "fresa") fresasSembradas++;

        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("Siembra realizada correctamente.");
        Console.ResetColor();
    }

    // 2. Regar parcela
    static void Regar(Parcela[,] parcelas, ref double dineroTotal, ref double totalEgresos, ref int riegosRealizados)
    {
        int f = LeerEntero($"Ingrese fila a regar (1 a {parcelas.GetLength(0)}): ", 1, parcelas.GetLength(0)) - 1;
        int c = LeerEntero($"Ingrese columna a regar (1 a {parcelas.GetLength(1)}): ", 1, parcelas.GetLength(1)) - 1;

        // No se puede regar una parcela vacía
        if (parcelas[f, c].siembra == "vacia")
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("No se puede regar una parcela vacía.");
            Console.ResetColor();
            return;
        }

        // Solo se puede regar una vez por mes
        if (parcelas[f, c].regadaEsteMes)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Esta parcela ya fue regada este mes.");
            Console.ResetColor();
            return;
        }

        const int costoRiego = 40;
        if (dineroTotal < costoRiego)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("No hay suficiente dinero para regar.");
            Console.ResetColor();
            return;
        }

        // Aplicar el riego: costo, registrar egreso, marcar como regada
        dineroTotal -= costoRiego;
        totalEgresos += costoRiego;
        riegosRealizados++;
        parcelas[f, c].regadaEsteMes = true;

        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine($"Parcela regada. Costo: Q{costoRiego}. Dinero restante: Q{dineroTotal}");
        Console.ResetColor();
    }

    // 3. Consultar parcela
    static void ConsultarParcela(Parcela[,] parcelas)
    {
        int f = LeerEntero($"Ingrese fila (1 a {parcelas.GetLength(0)}): ", 1, parcelas.GetLength(0)) - 1;
        int c = LeerEntero($"Ingrese columna (1 a {parcelas.GetLength(1)}): ", 1, parcelas.GetLength(1)) - 1;

        if (parcelas[f, c].siembra == "vacia")
        {
            Console.ForegroundColor = ConsoleColor.DarkBlue;
            Console.WriteLine("Parcela vacía. Disponible para siembra.");
            Console.ResetColor();
        }
        else
        {
            Console.WriteLine($"Tipo de cultivo: {parcelas[f, c].siembra}");
            Console.WriteLine($"Crecimiento: {parcelas[f, c].crecimientoActual} / {parcelas[f, c].mesesCrecimiento} meses");
            Console.WriteLine($"Regada este mes: {(parcelas[f, c].regadaEsteMes ? "Sí" : "No")}");
        }
    }

    // 4. Avanzar mes (la lógica más importante del sistema)
    static void AvanzarMes(Parcela[,] parcelas, ref int empleados, ref int mesesSimulados, ref double sueldoXempleado,
                           ref double dineroTotal, ref double totalIngresos, ref double totalEgresos, ref int mesesTotales)
    {
        // --- Paso 1: Pagar sueldos ---
        // Si no alcanza el dinero, la granja quiebra y termina la simulación
        double pago = empleados * sueldoXempleado;
        if (dineroTotal < pago)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("No hay suficiente dinero para pagar los sueldos. La granja quiebra.");
            dineroTotal = 0;
            mesesTotales = 0;  // Forzar salida del bucle principal
            Console.ResetColor();
            return;
        }
        dineroTotal -= pago;
        totalEgresos += pago;
        Console.WriteLine($"Pagados Q{pago} en sueldos.");

        // --- Paso 2: Crecimiento y cosecha ---
        // Recorremos toda la matriz de parcelas
        for (int i = 0; i < parcelas.GetLength(0); i++)
        {
            for (int j = 0; j < parcelas.GetLength(1); j++)
            {
                // Solo procesamos parcelas que no estén vacías
                if (parcelas[i, j].siembra != "vacia")
                {
                    // Si fue regada en el mes que acaba de terminar, crece 2; si no, crece 1
                    int incremento = parcelas[i, j].regadaEsteMes ? 2 : 1;
                    parcelas[i, j].crecimientoActual += incremento;

                    // Si alcanzó o superó los meses necesarios, se cosecha
                    if (parcelas[i, j].crecimientoActual >= parcelas[i, j].mesesCrecimiento)
                    {
                        double ingreso = parcelas[i, j].ingresos;
                        // Guardamos el tipo antes de limpiar la parcela, para poder contarlo
                        string tipoCosechado = parcelas[i, j].siembra;

                        Console.ForegroundColor = ConsoleColor.Magenta;
                        Console.WriteLine($"¡Cosecha de {tipoCosechado} en ({i + 1},{j + 1})! +Q{ingreso}");
                        Console.ResetColor();

                        dineroTotal += ingreso;
                        totalIngresos += ingreso;

                        // Incrementar contador de cosechas según el tipo
                        switch (tipoCosechado)
                        {
                            case "papa": papasCosechadas++; break;
                            case "tomate": tomatesCosechados++; break;
                            case "fresa": fresasCosechadas++; break;
                        }

                        // La parcela queda vacía después de cosechar
                        parcelas[i, j].sembrar("vacia");
                    }
                }
            }
        }

        // --- Paso 3: Reiniciar el estado de riego para el nuevo mes ---
        for (int i = 0; i < parcelas.GetLength(0); i++)
            for (int j = 0; j < parcelas.GetLength(1); j++)
                parcelas[i, j].regadaEsteMes = false;

        // --- Paso 4: Actualizar contadores de tiempo ---
        mesesSimulados++;
        mesesTotales--;
        Console.WriteLine($"Dinero actual: Q{dineroTotal}. Meses restantes: {mesesTotales}\n");
    }

    // ======================= REPORTE FINAL =======================
    static void MostrarReporteFinal(double dineroTotal, double totalIngresos, double totalEgresos,
                                    int mesesSimulados, int riegosRealizados, Parcela[,] parcelas)
    {
        // Contamos cuántas parcelas están vacías al final
        int vacias = 0;
        for (int i = 0; i < parcelas.GetLength(0); i++)
            for (int j = 0; j < parcelas.GetLength(1); j++)
                if (parcelas[i, j].siembra == "vacia")
                    vacias++;

        Console.ForegroundColor = ConsoleColor.DarkBlue;
        Console.WriteLine("\n===== REPORTE FINAL =====");
        Console.WriteLine($"Dinero final: Q{dineroTotal}");
        Console.WriteLine($"Total de ingresos: Q{totalIngresos}");
        Console.WriteLine($"Total de egresos: Q{totalEgresos}");
        Console.WriteLine($"Meses simulados: {mesesSimulados}");
        Console.WriteLine("\n--- Siembras por tipo ---");
        Console.WriteLine($"Papa: {papasSembradas}");
        Console.WriteLine($"Tomate: {tomatesSembrados}");
        Console.WriteLine($"Fresa: {fresasSembradas}");
        Console.WriteLine("\n--- Cosechas por tipo ---");
        Console.WriteLine($"Papa: {papasCosechadas}");
        Console.WriteLine($"Tomate: {tomatesCosechados}");
        Console.WriteLine($"Fresa: {fresasCosechadas}");
        Console.WriteLine($"\nTotal de riegos realizados: {riegosRealizados}");
        Console.WriteLine($"Parcelas vacías al finalizar: {vacias}");
        Console.ForegroundColor = ConsoleColor.DarkMagenta;
        Console.WriteLine("-Muchas gracias-");
        Console.ResetColor();
    }

    // Estas funciones garantizan que el usuario ingrese datos válidos, evitando
    // que el programa se caiga por errores de tipo o rango.
    static int LeerEntero(string mensaje, int min, int max = int.MaxValue)
    {
        int valor;
        while (true)
        {
            Console.Write(mensaje);
            if (int.TryParse(Console.ReadLine(), out valor) && valor >= min && valor <= max)
                return valor;
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"Error: Ingrese un número entero entre {min} y {(max == int.MaxValue ? "infinito" : max.ToString())}.");
            Console.ResetColor();
        }
    }

    static double LeerDouble(string mensaje, double min)
    {
        double valor;
        while (true)
        {
            Console.Write(mensaje);
            if (double.TryParse(Console.ReadLine(), out valor) && valor >= min)
                return valor;
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"Error: Ingrese un número válido mayor o igual a {min}.");
            Console.ResetColor();
        }
    }
}