﻿using System;

class Program
{
    static void Main()
    {
        int opcion;
        do
        {
           
            Console.WriteLine("1. Ejercicio 1: Saludo modularizado");
            Console.WriteLine("2. Ejercicio 2: Calculadora de áreas");
            Console.WriteLine("3. Ejercicio 3: Figuras");
            Console.WriteLine("4. Ejercicio 4: Registro de notas");
            Console.WriteLine("5. Ejercicio 5: Intercambio de valores");
            Console.WriteLine("6. Salir");
            Console.Write("Seleccione una opción: ");
            opcion = int.Parse(Console.ReadLine());

            switch (opcion)
            {
                case 1: Ejercicio1(); break;
                case 2: Ejercicio2(); break;
                case 3: Ejercicio3(); break;
                case 4: Ejercicio4(); break;
                case 5: Ejercicio5(); break;
                case 6: Console.WriteLine("Saliendo"); break;
                default: Console.WriteLine("Opción no válida."); break;
            }

            if (opcion != 6)
            {
                Console.WriteLine("\nPresione cualquier tecla para volver al menú...");
                Console.ReadKey();
            }
        } while (opcion != 6);
    }

 
    
    
    static void Ejercicio1()
    {
        
        Console.Write("Ingrese su nombre: ");
        string nombre = Console.ReadLine();
        MostrarSaludo(nombre);
        MostrarInfoCurso();
    }

    static void MostrarSaludo(string nombre)
    {
        Console.WriteLine($"¡Hola, {nombre}! Bienvenido al laboratorio pensamiento computacional.");
    }

    static void MostrarInfoCurso()
    {
        Console.WriteLine("Curso: Logica de algortimos y programacion");
        Console.WriteLine("Laboratorio: 9");
    }


    static void Ejercicio2()
    {

        
        Console.WriteLine("1. Cuadrado");
        Console.WriteLine("2. Rectángulo");
        Console.WriteLine("3. Triángulo");
        Console.WriteLine("4. Círculo");
        Console.Write("Seleccione una opción: ");
        int op = int.Parse(Console.ReadLine());

        switch (op)
        {
            case 1:
                Console.Write("Ingrese el lado: ");
                double lado = double.Parse(Console.ReadLine());
                AreaCuadrado(lado);
                break;
            case 2:
                Console.Write("Ingrese la base: ");
                double baseRect = double.Parse(Console.ReadLine());
                Console.Write("Ingrese la altura: ");
                double alturaRect = double.Parse(Console.ReadLine());
                AreaRectangulo(baseRect, alturaRect);
                break;
            case 3:
                Console.Write("Ingrese la base: ");
                double baseTri = double.Parse(Console.ReadLine());
                Console.Write("Ingrese la altura: ");
                double alturaTri = double.Parse(Console.ReadLine());
                AreaTriangulo(baseTri, alturaTri);
                break;
            case 4:
                Console.Write("Ingrese el radio: ");
                double radio = double.Parse(Console.ReadLine());
                AreaCirculo(radio);
                break;
            default:
                Console.WriteLine("Opción no válida.");
                break;
        }
    }

    static void AreaCuadrado(double lado)
    {
        double area = lado * lado;
        Console.WriteLine($"El área del cuadrado es: {area}");
    }

    static void AreaRectangulo(double baseRect, double altura)
    {
        double area = baseRect * altura;
        Console.WriteLine($"El área del rectángulo es: {area}");
    }

    static void AreaTriangulo(double baseTri, double altura)
    {
        double area = (baseTri * altura) / 2;
        Console.WriteLine($"El área del triángulo es: {area}");
    }

    static void AreaCirculo(double radio)
    {
        double area = (radio * 3.1416 * radio );
        Console.WriteLine($"El área del circulo es: {area}");
    }

   
    static void Ejercicio3()
    {
      
        int opcion;
        do
        {
            Console.WriteLine("1. Cuadrado");
            Console.WriteLine("2. Triángulo");
            Console.WriteLine("3. Línea");
            Console.WriteLine("4. Salir");
            Console.Write("Seleccione una figura: ");
            opcion = int.Parse(Console.ReadLine());

            if (opcion >= 1 && opcion <= 3)
            {
                Console.Write("Ingrese N: ");
                int n = int.Parse(Console.ReadLine());

                switch (opcion)
                {
                    case 1: DibujarCuadrado(n); break;
                    case 2: DibujarTriangulo(n); break;
                    case 3: DibujarLinea(n); break;
                }
            }
            else if (opcion != 4)
            {
                Console.WriteLine("Opción no válida.");
            }

        } while (opcion != 4);
    }

    static void DibujarCuadrado(int n)
    {
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                Console.Write("*");
            }
            Console.WriteLine();
        }
    }

    static void DibujarTriangulo(int n)
    {
        for (int i = 1; i <= n; i++)
        {
            for (int j = 0; j < i; j++)
            {
                Console.Write("*");
            }
            Console.WriteLine();
        }
    }

    static void DibujarLinea(int n)
    {
        for (int i = 0; i < n; i++)
        {
            Console.Write("*");
        }
        Console.WriteLine();
    }

 
    static void Ejercicio4()
    {
        
        int aprobados = 0, reprobados = 0;
        double suma = 0;
        int contador = 1;

        while (contador <= 5)
        {
            Console.Write($"Ingrese nota {contador}: ");
            double nota = double.Parse(Console.ReadLine());
            EvaluarNota(nota, ref aprobados, ref reprobados, ref suma);
            contador++;
        }

        MostrarResumen(aprobados, reprobados, suma);
    }

    static void EvaluarNota(double nota, ref int aprobados, ref int reprobados, ref double suma)
    {
        if (nota >= 61)
        {
            Console.WriteLine("Aprobado");
            aprobados++;
        }
        else
        {
            Console.WriteLine("Reprobado");
            reprobados++;
        }
        suma += nota;
    }

    static void MostrarResumen(int aprobados, int reprobados, double suma)
    {
        double promedio = suma / 5;
        Console.WriteLine($"\n RESUMEN");
        Console.WriteLine($"Promedio: {promedio:F2}");
        Console.WriteLine($"Aprobados: {aprobados}");
        Console.WriteLine($"Reprobados: {reprobados}");
    }


    static void Ejercicio5()
    {
        Console.Write("Ingrese el primer número: ");
        int a = int.Parse(Console.ReadLine());
        Console.Write("Ingrese el segundo número: ");
        int b = int.Parse(Console.ReadLine());
        Console.WriteLine($"a = {a}, b = {b}");
        Intercambiar(ref a, ref b);
        Console.WriteLine($"a = {a}, b = {b}");
    }

    static void Intercambiar(ref int x, ref int y)
    {
        int temp = x;
        x = y;
        y = temp;
    }
}