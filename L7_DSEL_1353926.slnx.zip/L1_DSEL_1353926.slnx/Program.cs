﻿using System;

class Program
{
    static void Main()
    {
       
        Console.WriteLine("1. Suma controlada por contador");
        Console.WriteLine("2. Menú repetitivo de conversión de unidades");
        Console.WriteLine("3. Juego: Adivina el número");
        Console.WriteLine("4. Control de intentos: PIN de acceso");
        Console.Write("Opción: ");
        int opcion = int.Parse(Console.ReadLine());

        Console.Clear();

        switch (opcion)
        {
            case 1: Ejercicio1(); break;
            case 2: Ejercicio2(); break;
            case 3: Ejercicio3(); break;
            case 4: Ejercicio4(); break;
            default: Console.WriteLine("Opción no válida."); break;
        }
    }

    static void Ejercicio1()
    {
        Console.WriteLine("EJERCICIO 1: SUMA CONTROLADA POR CONTADOR\n");

        int n;
        do
        {
            Console.Write("¿Cuántos números sumara? (N > 0): ");
            n = int.Parse(Console.ReadLine());
            if (n <= 0) Console.WriteLine("Error, N debe ser mayor que 0. Intente de nuevo.");
        } while (n <= 0);

        int contador = 0;
        double suma = 0;

        while (contador < n)
        {
            Console.Write($"Ingrese el número #{contador + 1}: ");
            suma += double.Parse(Console.ReadLine());
            contador++;
        }

        Console.WriteLine($"\nTotal de la suma: {suma}");
        Console.WriteLine($"Promedio: {suma / n:F2}");
        Console.ReadKey();
    }

    static void Ejercicio2()
    {
        Console.WriteLine("EJERCICIO 2: MENÚ DE CONVERSIÓN DE UNIDADES\n");

        int opcion;
        do
        {
            Console.WriteLine("\nMENÚ");
            Console.WriteLine("1. Convertir Celsius a Fahrenheit");
            Console.WriteLine("2. Convertir Fahrenheit a Celsius");
            Console.WriteLine("3. Convertir Kilómetros a Millas");
            Console.WriteLine("4. Salir");
            Console.Write("Seleccione una opción: ");
            opcion = int.Parse(Console.ReadLine());
            switch (opcion)
            {
                case 1:
                    Console.Write("Ingrese grados Celsius: ");
                    double gradosc = double.Parse(Console.ReadLine());
                    Console.WriteLine($"Resultado: {(gradosc * 9 / 5) + 32:F2} °F");
                    break;
                case 2:
                    Console.Write("Ingrese grados Fahrenheit: ");
                    double fah = double.Parse(Console.ReadLine());
                    Console.WriteLine($"Resultado: {(fah - 32) * 5 / 9:F2} °C");
                    break;
                case 3:
                    Console.Write("Ingrese kilómetros: ");
                    double x = double.Parse(Console.ReadLine());
                    Console.WriteLine($"Resultado: {x * 0.621371:F2} millas");
                    break;
                case 4:
                    Console.WriteLine("Saliendo del programa...");
                    break;
                default:
                    Console.WriteLine("Opción inválida. Intente de nuevo.");
                    break;
            }
        } while (opcion != 4);

        Console.ReadKey();
    }

    static void Ejercicio3()
    {
        Console.WriteLine("EJERCICIO 3: ADIVINA EL NÚMERO\n");

        Random random = new Random();
        int num = random.Next(1, 101);
        int intento;
        int containt = 0;

        Console.WriteLine("Adivina el numero entre 1 y 100");

        do
        {
            Console.Write("Ingresa el número: ");
            intento = int.Parse(Console.ReadLine());

            if (intento < 1 || intento > 100)
            {
                Console.WriteLine("Número fuera de rango. No cuenta como intento.");
                continue;
            }

            containt++;

            if (intento < num)
                Console.WriteLine("Más alto");
            else if (intento > num)
                Console.WriteLine("Más bajo");
            else
                Console.WriteLine($"Correcto, lo lograste en {containt} intentos.");

        } while (intento != num);

        Console.ReadKey();
    }

    static void Ejercicio4()
    {
        Console.WriteLine("EJERCICIO 4: ACCESO CON PIN\n");

        int pinbueno = 1234;
        int maxint = 3;
        int intentocont = 0;
        int pinusuario;

        do
        {
            Console.Write("Ingrese el PIN (4 dígitos): ");
            pinusuario = int.Parse(Console.ReadLine());
            intentocont++;

            if (pinusuario == pinbueno)
            {
                Console.WriteLine("Acceso concedido");
                break;
            }

            Console.WriteLine("PIN incorrecto");

            if (intentocont == maxint)
            {
                Console.WriteLine("Cuenta bloqueada");
                break;
            }

        } while (intentocont < maxint);

        Console.ReadKey();
    }
}