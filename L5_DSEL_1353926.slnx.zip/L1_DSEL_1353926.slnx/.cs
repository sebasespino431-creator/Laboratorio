﻿using System;
class Program
{
    static void Main()
    {
        int opcion;

        do
        {
            Console.Clear();
            Console.WriteLine("=== MENÚ DE EJERCICIOS ===");
            Console.WriteLine("1. Clasificación de vehículos");
            Console.WriteLine("2. Aumento de límite de crédito - Banco Industrial");
            Console.WriteLine("3. Evaluación de empleados");
            Console.WriteLine("4. Pizzería Bella Napoli");
            Console.WriteLine("0. Salir");
            Console.Write("\nSeleccione una opción: ");

            if (int.TryParse(Console.ReadLine(), out opcion))
            {
                switch (opcion)
                {
                    case 1:
                        Ejercicio1_Vehiculos();
                        break;
                    case 2:
                        Ejercicio2_Credito();
                        break;
                    case 3:
                        Ejercicio3_Evaluacion();
                        break;
                    case 4:
                        Ejercicio4_Pizzeria();
                        break;
                    case 0:
                        Console.WriteLine("¡Hasta luego!");
                        break;
                    default:
                        Console.WriteLine("Opción no válida. Presione una tecla para continuar...");
                        Console.ReadKey();
                        break;
                }

                // Entrada de usuario







                // Salida de datos

            }
}