﻿using System;

class Program
{
    static void Main()
    {
       int opcion;
        do
        {
            Console.WriteLine("1. Validación de contraseña");
            Console.WriteLine("2. Invertir texto");
            Console.WriteLine("3. Suma y promedio de arreglo");
            Console.WriteLine("4. Buscar número en arreglo");
            Console.WriteLine("5. Nombres en arreglo");
            Console.WriteLine("6. Salir");
            Console.Write("Seleccione una opción: ");

            if (int.TryParse(Console.ReadLine(), out opcion))
            {
                switch (opcion)
                {
                    case 1: Ejercicio1_ValidarContrasena(); break;
                    case 2: Ejercicio2_InvertirTexto(); break;
                    case 3: Ejercicio3_SumaPromedio(); break;
                    case 4: Ejercicio4_BuscarNumero(); break;
                    case 5: Ejercicio5_NombresArreglo(); break;
                    case 6: Console.WriteLine("¡Hasta luego!"); break;
                    default: Console.WriteLine("Opción no válida."); break;
                }
            }
        } while (opcion != 6);
    }

    static void Ejercicio1_ValidarContrasena()
    {
        Console.Write("Ingrese su contraseña: ");
        string contraseña = Console.ReadLine();
        bool longitudValida = contraseña.Length >= 8;
        bool tieneMayuscula = false;
        bool tieneNumero = false;
        bool tieneEspecial = false;
        string caracteresEspeciales = "@#$%";
        foreach (char c in contraseña)
        {
            if (char.IsUpper(c)) tieneMayuscula = true;
            if (char.IsDigit(c)) tieneNumero = true;
            if (caracteresEspeciales.Contains(c)) tieneEspecial = true;
        }
        if (longitudValida && tieneMayuscula && tieneNumero && tieneEspecial)
        {
            Console.WriteLine("Contraseña válida");
        }
        else
        {
            Console.Write("Inválida: ");
            List<string> faltantes = new List<string>();
            if (!longitudValida) faltantes.Add("faltan mas caracteres (mínimo 8 caracteres)");
            if (!tieneMayuscula) faltantes.Add("falta por lo menos una mayúscula");
            if (!tieneNumero) faltantes.Add("falta por lo menos un número");
            if (!tieneEspecial) faltantes.Add("falta por lo menos un carácter especial (@, #, $, %)");
            Console.WriteLine(string.Join(", ", faltantes));
        }
    }
    static void Ejercicio2_InvertirTexto() 
    {
       
    }
    static void Ejercicio3_SumaPromedio()
    {
        Console.Write("¿Cuántos números desea ingresar? ");
        int cantidad = int.Parse(Console.ReadLine());
        int[] numeros = new int[cantidad];
        int suma = 0;
        for (int i = 0; i < cantidad; i++)
        {
            Console.Write($"Ingrese el número {i + 1}: ");
            numeros[i] = int.Parse(Console.ReadLine());
            suma += numeros[i];
        }
        double promedio = (double)suma / cantidad;
        int mayor = numeros[0];
        int menor = numeros[0];

        for (int i = 1; i < cantidad; i++)
        {
            if (numeros[i] > mayor) mayor = numeros[i];
            if (numeros[i] < menor) menor = numeros[i];
        }
        Console.Write("Números ingresados: ");
        for (int i = 0; i < cantidad; i++)
        {
            Console.Write(numeros[i]);
            if (i < cantidad - 1) Console.Write(", ");
        }
        Console.WriteLine($"\nSuma = {suma}");
        Console.WriteLine($"Promedio = {promedio:F2}");
        Console.WriteLine($"Mayor = {mayor}");
        Console.WriteLine($"Menor = {menor}");
    }

    
    static void Ejercicio4_BuscarNumero()
    {
       
        int[] arreglo = new int[8];

        Console.WriteLine("Ingrese 8 números enteros:");
        for (int i = 0; i < 8; i++)
        {
            Console.Write($"Número {i + 1}: ");
            arreglo[i] = int.Parse(Console.ReadLine());
        }

        Console.Write("\nIngrese el número a buscar: ");
        int buscar = int.Parse(Console.ReadLine());


        bool encontrado = false;
        int posicion = -1;

        for (int i = 0; i < arreglo.Length; i++)
        {
            if (arreglo[i] == buscar)
            {
                encontrado = true;
                posicion = i;
                break; 
            }
        }

        
        Console.Write("\nArreglo: ");
        for (int i = 0; i < arreglo.Length; i++)
        {
            Console.Write(arreglo[i]);
            if (i < arreglo.Length - 1) Console.Write(", ");
        }
        Console.WriteLine($"; Buscar: {buscar}");

        if (encontrado)
        {
            Console.WriteLine($"El número sí existe en la posición {posicion}");
        }
        else
        {
            Console.WriteLine("El número no existe en el arreglo");
        }
    }

   
    static void Ejercicio5_NombresArreglo()
    {
        Console.WriteLine("=== EJERCICIO 5: NOMBRES EN ARREGLO ===\n");
        string[] nombres = new string[5];

        
        for (int i = 0; i < 5; i++)
        {
            Console.Write($"Ingrese el nombre {i + 1}: ");
            nombres[i] = Console.ReadLine();
        }

        
        int contadorMasDe5 = 0;
        string nombreMasLargo = nombres[0];

        foreach (string nombre in nombres)
        {
            if (nombre.Length > 5) contadorMasDe5++;
            if (nombre.Length > nombreMasLargo.Length) nombreMasLargo = nombre;
        }

      
        Console.WriteLine("\n--- RESULTADOS ---");
        Console.Write("Nombres ingresados: ");
        for (int i = 0; i < nombres.Length; i++)
        {
            Console.Write(nombres[i]);
            if (i < nombres.Length - 1) Console.Write(", ");
        }

        Console.WriteLine($"\nMás de 5 letras: {contadorMasDe5}");
        Console.WriteLine($"Nombre más largo: {nombreMasLargo}");
    }
}