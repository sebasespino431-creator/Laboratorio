﻿using System;

class Program
{
    static void Main()
    {
        // ==================== EJERCICIO 1: Registro de Nave Espacial ====================
        Console.WriteLine("=== EJERCICIO 1: Ficha Técnica de la Nave ===\n");

        string modelo = "X-302 Estelar";
        int capacidadCarga = 1500;        // en toneladas
        float nivelCombustible = 87.5f;   // porcentaje
        bool motorSaltoActivo = true;

        // Impresión usando concatenación
        Console.WriteLine("Modelo: " + modelo + " | Capacidad de carga: " + capacidadCarga + " t" +
                          " | Nivel de combustible: " + nivelCombustible + "%" +
                          " | Motor de salto activo: " + motorSaltoActivo);
        Console.WriteLine("\n----------------------------------------\n");

        // ==================== EJERCICIO 2: Expansión de Memoria (Conversión Implícita) ====================
        Console.WriteLine("=== EJERCICIO 2: Conversión Implícita ===\n");

        short sensoresActivos = 128;
        int registroProcesador;
        double precisionTotal;

        // Asignación implícita (short -> int)
        registroProcesador = sensoresActivos;
        // Asignación implícita (int -> double)
        precisionTotal = registroProcesador;

        Console.WriteLine("Valor en precisionTotal: " + precisionTotal);
        Console.WriteLine("\n----------------------------------------\n");

        // ==================== EJERCICIO 3: Ajuste de Energía (Casting Explícito) ====================
        Console.WriteLine("=== EJERCICIO 3: Casting Explícito ===\n");

        double energiaGenerada = 987.65;
        int energiaLimitada = (int)energiaGenerada;   // Trunca los decimales

        Console.WriteLine("Energía generada original: " + energiaGenerada);
        Console.WriteLine("Energía limitada (entero truncado): " + energiaLimitada);
        Console.WriteLine("\n----------------------------------------\n");

        // ==================== EJERCICIO 4: Recepción de Coordenadas (Parse) ====================
        Console.WriteLine("=== EJERCICIO 4: Parse de coordenadas ===\n");

        Console.Write("Ingrese la distancia al planeta más cercano (ej. 500): ");
        string entradaRadar = Console.ReadLine();
        int distanciaPlaneta = int.Parse(entradaRadar);
        int distanciaConSeguridad = distanciaPlaneta + 100;

        Console.WriteLine("Distancia original: " + distanciaPlaneta);
        Console.WriteLine("Distancia con margen de seguridad (+100): " + distanciaConSeguridad);
        Console.WriteLine("\n----------------------------------------\n");

        // ==================== EJERCICIO 5: Panel de Control (Clase Convert) ====================
        Console.WriteLine("=== EJERCICIO 5: Convert (bool y double) ===\n");

        string señalOxigeno = "true";
        bool oxigenoOk = Convert.ToBoolean(señalOxigeno);

        string temperaturaCabina = "22.8";
        double temperatura = Convert.ToDouble(temperaturaCabina);

        Console.WriteLine("Señal de oxígeno (bool): " + oxigenoOk);
        Console.WriteLine("Temperatura de cabina (double): " + temperatura);
        Console.WriteLine("\n----------------------------------------\n");

        // ==================== EJERCICIO 6: Reporte de Misión (ToString y Formato) ====================
        Console.WriteLine("=== EJERCICIO 6: Formato con ToString ===\n");

        double velocidadLuz = 299792.458;
        string velocidadStr = velocidadLuz.ToString();          // Conversión simple
        string velocidadFormateada = velocidadLuz.ToString("N3"); // Miles y 3 decimales

        Console.WriteLine("Velocidad de la luz (ToString simple): " + velocidadStr);
        Console.WriteLine("Velocidad de la luz (ToString con N3): " + velocidadFormateada);
        Console.WriteLine("\n----------------------------------------\n");

        // ==================== EJERCICIO 7: Reto Final - Calculadora de Suministros ====================
        Console.WriteLine("=== EJERCICIO 7: Calculadora de Suministros ===\n");

        Console.Write("Ingrese el Precio por Galón de Litio: ");
        string precioTexto = Console.ReadLine();
        double precioGalon = Convert.ToDouble(precioTexto);   // también se puede usar double.Parse

        double impuestoGalactico = precioGalon * 0.12;
        double costoTotal = precioGalon + impuestoGalactico;

        // Casting explícito a int para redondear hacia abajo (truncar)
        int costoTotalInt = (int)costoTotal;

        Console.WriteLine("Precio por galón: " + precioGalon);
        Console.WriteLine("Impuesto galáctico (12%): " + impuestoGalactico);
        Console.WriteLine("Costo total (sin redondeo): " + costoTotal);
        Console.WriteLine("El costo final de suministro es: " + costoTotalInt);

        Console.WriteLine("\n----------------------------------------\n");
        Console.WriteLine("Fin del laboratorio. Presione cualquier tecla para salir...");
        Console.ReadKey();
    }
}