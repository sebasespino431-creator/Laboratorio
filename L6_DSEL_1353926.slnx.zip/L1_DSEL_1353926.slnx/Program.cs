﻿using System;

class Program
{
    static void Main()
    {
        int opcionmenu;

        do
        {

            Console.WriteLine("1. Ejercicio 1: Clasificación de vehículos");
            Console.WriteLine("2. Ejercicio 2: Aumento de límite de crédito - Banco Industrial");
            Console.WriteLine("3. Ejercicio 3: Evaluación de empleados");
            Console.WriteLine("4. Ejercicio 4: Pizzería Bella Napoli");
            Console.WriteLine("0. Salir");
            Console.Write("\nSeleccione una opción: ");

            if (int.TryParse(Console.ReadLine(), out opcionmenu))
            {
                switch (opcionmenu)
                {
                    case 1: ejercicio1(); break;
                    case 2: ejercicio2(); break;
                    case 3: ejercicio3(); break;
                    case 4: ejercicio4(); break;
                    case 0: Console.WriteLine("¡Gracias por utilizar el programa! Hasta luego."); break;
                    default:
                        Console.WriteLine("Error: Opción no válida.");
                        Console.ReadKey();
                        break;
                }
            }
            else
            {
                Console.WriteLine("Error: Debe ingresar un número válido.");
                Console.ReadKey();
            }

        } while (opcionmenu != 0);
    }

    static void ejercicio1()
    {
        Console.Clear();
        Console.WriteLine("=== EJERCICIO 1: CLASIFICACIÓN DE VEHÍCULOS ===\n");
        Console.WriteLine("1: Bicicleta\n2: Motocicleta\n3: Auto\n4: Camión\n5: Autobús");
        Console.Write("\nIngrese el tipo de vehículo (1-5): ");

        if (int.TryParse(Console.ReadLine(), out int tipovehiculo))
        {
            switch (tipovehiculo)
            {
                case 1: Console.WriteLine("\nClasificación: No motorizado"); break;
                case 2: Console.WriteLine("\nClasificación: Ligero"); break;
                case 3: Console.WriteLine("\nClasificación: Mediano"); break;
                case 4: Console.WriteLine("\nClasificación: Pesado"); break;
                case 5: Console.WriteLine("\nClasificación: Transporte público"); break;
                default: Console.WriteLine("\nError: Número fuera de rango."); break;
            }
        }
        else Console.WriteLine("\nError: Debe ingresar un número válido.");

        Console.WriteLine("\nPresione una tecla para continuar...");
        Console.ReadKey();
    }

    static void ejercicio2()
    {
        Console.Clear();
        Console.WriteLine("=== EJERCICIO 2: BANCO INDUSTRIAL ===\n");
        Console.WriteLine("1: Tipo 1 (25%)\n2: Tipo 2 (35%)\n3: Tipo 3 (40%)\nOtros: 50%");
        Console.Write("\nIngrese el tipo de tarjeta: ");

        if (int.TryParse(Console.ReadLine(), out int tipotarjeta))
        {
            Console.Write("Ingrese el límite actual: Q");
            if (double.TryParse(Console.ReadLine(), out double limiteactual))
            {
                double porcentaje;
                switch (tipotarjeta)
                {
                    case 1: porcentaje = 0.25; break;
                    case 2: porcentaje = 0.35; break;
                    case 3: porcentaje = 0.40; break;
                    default: porcentaje = 0.50; break;
                }

                double nuevolimite = limiteactual * (1 + porcentaje);
                Console.WriteLine($"\nLímite actual: Q{limiteactual:F2}");
                Console.WriteLine($"Aumento: {porcentaje * 100}%");
                Console.WriteLine($"Nuevo límite: Q{nuevolimite:F2}");
            }
            else Console.WriteLine("\nError: Monto inválido.");
        }
        else Console.WriteLine("\nError: Tipo de tarjeta inválido.");

        Console.WriteLine("\nPresione una tecla para continuar...");
        Console.ReadKey();
    }

    static void ejercicio3()
    {
        Console.Clear();
        Console.WriteLine("=== EJERCICIO 3: EVALUACIÓN DE EMPLEADOS ===\n");
        Console.WriteLine("0.0 - Inaceptable\n0.4 - Aceptable\n0.6+ - Meritorio");
        Console.Write("\nIngrese la puntuación: ");

        if (double.TryParse(Console.ReadLine(), out double puntuacion))
        {
            if (puntuacion == 0.0)
                Console.WriteLine($"\nNivel: Inaceptable\nDinero: {2400 * puntuacion:C2}€");
            else if (puntuacion == 0.4)
                Console.WriteLine($"\nNivel: Aceptable\nDinero: {2400 * puntuacion:C2}€");
            else if (puntuacion >= 0.6)
                Console.WriteLine($"\nNivel: Meritorio\nDinero: {2400 * puntuacion:C2}€");
            else
                Console.WriteLine("\nError: Puntuación no válida.");
        }
        else Console.WriteLine("\nError: Debe ingresar un número válido.");

        Console.WriteLine("\nPresione una tecla para continuar...");
        Console.ReadKey();
    }

    static void ejercicio4()
    {
        Console.Clear();
        Console.WriteLine("=== EJERCICIO 4: PIZZERÍA BELLA NAPOLI ===\n");
        Console.WriteLine("1. Pizza Vegetariana\n2. Pizza No vegetariana");
        Console.Write("Seleccione (1-2): ");

        if (int.TryParse(Console.ReadLine(), out int tipopizza) && (tipopizza == 1 || tipopizza == 2))
        {
            bool vegetariana = (tipopizza == 1);
            string tipotexto = vegetariana ? "Vegetariana" : "No vegetariana";

            Console.Clear();
            Console.WriteLine($"=== PIZZA {tipotexto.ToUpper()} ===\n");
            Console.WriteLine("Base: Mozzarella y Tomate");
            Console.WriteLine("\nIngredientes disponibles:");

            if (vegetariana)
            {
                Console.WriteLine("1. Pimiento\n2. Tofu");
                Console.Write("\nSeleccione (1-2): ");
            }
            else
            {
                Console.WriteLine("1. Peperoni\n2. Jamón\n3. Salmón");
                Console.Write("\nSeleccione (1-3): ");
            }

            if (int.TryParse(Console.ReadLine(), out int opcioningrediente))
            {
                string ingrediente = "";
                bool valido = true;

                if (vegetariana)
                {
                    if (opcioningrediente == 1) ingrediente = "Pimiento";
                    else if (opcioningrediente == 2) ingrediente = "Tofu";
                    else valido = false;
                }
                else
                {
                    if (opcioningrediente == 1) ingrediente = "Peperoni";
                    else if (opcioningrediente == 2) ingrediente = "Jamón";
                    else if (opcioningrediente == 3) ingrediente = "Salmón";
                    else valido = false;
                }

                if (!valido)
                {
                    Console.WriteLine("\nError: Ingrediente no válido.");
                    Console.ReadKey();
                    return;
                }

                Console.WriteLine($"\nPizza: {tipotexto}\nIngredientes: Mozzarella, Tomate, {ingrediente}");
            }
            else Console.WriteLine("\nError: Número inválido.");
        }
        else Console.WriteLine("\nError: Opción no válida.");

        Console.WriteLine("\nPresione una tecla para continuar...");
        Console.ReadKey();
    }
}