﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("LABORATORIO 12");
        Console.WriteLine("EJERCICIO 1");
        Ejercicio1();
        Console.WriteLine("EJERCICIO 2");
        Ejercicio2();
        Console.WriteLine("EJERCICIO 3");
        Ejercicio3();
        Console.WriteLine("EJERCICIO 4");
        Ejercicio4();
    }
    static void Ejercicio1()
    {
        int[,] matriz = new int[4, 4];
        LlenarMatriz(matriz);

        Console.Write("Ingrese fila a sumar: ");
        int fila = int.Parse(Console.ReadLine());
        Console.Write("Ingrese columna a sumar: ");
        int col = int.Parse(Console.ReadLine());

        int sumaF = SumaFila(matriz, fila);
        int sumaC = SumaColumna(matriz, col);

        Console.WriteLine($"Suma fila {fila}: {sumaF}");
        Console.WriteLine($"Suma columna {col}: {sumaC}");
    }

    static void LlenarMatriz(int[,] m)
    {
        Console.WriteLine("Ingrese valores para matriz 4x4:");
        for (int i = 0; i < 4; i++)
            for (int j = 0; j < 4; j++)
            {
                Console.Write($"Elemento [{i},{j}]: ");
                m[i, j] = int.Parse(Console.ReadLine());
            }
    }

    static int SumaFila(int[,] m, int fila)
    {
        int suma = 0;
        for (int j = 0; j < 4; j++)
            suma += m[fila, j];
        return suma;
    }

    static int SumaColumna(int[,] m, int col)
    {
        int suma = 0;
        for (int i = 0; i < 4; i++)
            suma += m[i, col];
        return suma;
    }

    
    static void Ejercicio2()
    {
        float[,] matriz = new float[3, 5];
        CargarMatriz(matriz);
        float mayor = MayorMatriz(matriz);
        Console.WriteLine($"El mayor valor de la matriz es: {mayor}");
    }

    static void CargarMatriz(float[,] m)
    {
        Console.WriteLine("Ingrese valores para matriz 3x5:");
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 5; j++)
            {
                Console.Write($"Elemento [{i},{j}]: ");
                m[i, j] = float.Parse(Console.ReadLine());
            }
    }

    static float MayorMatriz(float[,] m)
    {
        float mayor = m[0, 0];
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 5; j++)
                if (m[i, j] > mayor)
                    mayor = m[i, j];
        return mayor;
    }

    static void Ejercicio3()
    {
        int[,] A = new int[3, 2];
        int[,] B = new int[3, 2];
        int[,] R = new int[3, 2];

        Console.WriteLine("Matriz A:");
        LlenarMatrizAB(A);
        Console.WriteLine("Matriz B:");
        LlenarMatrizAB(B);

        Multiplicar(A, B, R);
        Console.WriteLine("Resultado de multiplicación elemento a elemento:");
        MostrarMatriz(R);
    }

    static void LlenarMatrizAB(int[,] m)
    {
        for (int i = 0; i < m.GetLength(0); i++)
            for (int j = 0; j < m.GetLength(1); j++)
            {
                Console.Write($"Elemento [{i},{j}]: ");
                m[i, j] = int.Parse(Console.ReadLine());
            }
    }

    static void Multiplicar(int[,] A, int[,] B, int[,] R)
    {
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 2; j++)
                R[i, j] = A[i, j] * B[i, j];
    }

    static void MostrarMatriz(int[,] m)
    {
        for (int i = 0; i < m.GetLength(0); i++)
        {
            for (int j = 0; j < m.GetLength(1); j++)
                Console.Write(m[i, j] + "\t");
            Console.WriteLine();
        }
    }
    static void Ejercicio4()
    {
        int[,] matriz = new int[5, 5];
        LlenarMatriz5x5(matriz);

        int diagPrincipal = SumaDiagonalPrincipal(matriz);
        int diagSecundaria = SumaDiagonalSecundaria(matriz);

        Console.WriteLine($"Suma diagonal principal: {diagPrincipal}");
        Console.WriteLine($"Suma diagonal secundaria: {diagSecundaria}");
    }

    static void LlenarMatriz5x5(int[,] m)
    {
        Console.WriteLine("Ingrese valores para matriz 5x5:");
        for (int i = 0; i < 5; i++)
            for (int j = 0; j < 5; j++)
            {
                Console.Write($"Elemento [{i},{j}]: ");
                m[i, j] = int.Parse(Console.ReadLine());
            }
    }

    static int SumaDiagonalPrincipal(int[,] m)
    {
        int suma = 0;
        for (int i = 0; i < 5; i++)
            suma += m[i, i];
        return suma;
    }

    static int SumaDiagonalSecundaria(int[,] m)
    {
        int suma = 0;
        for (int i = 0; i < 5; i++)
            suma += m[i, 4 - i];
        return suma;
    }
}