﻿using System;

class Program
{
    static void Main()
    {
        Ejercicio1();
        Ejercicio2();
        Ejercicio3();
        Ejercicio4();
        Ejercicio5();
    }

    static void Ejercicio1()
    {
        Console.WriteLine("--- Ejercicio 1 ---");
        string nombre;
        int edad;
        Console.Write("Ingrese su nombre: ");
        nombre = Console.ReadLine();
        Console.Write("Ingrese su edad: ");
        while (!int.TryParse(Console.ReadLine(), out edad))
            Console.Write("Inválido, ingrese edad: ");
        Console.WriteLine("Hola " + nombre);
        Console.WriteLine("Tienes " + edad + " años");
        Console.WriteLine(edad >= 18 ? "Eres mayor de edad" : "Eres menor de edad");

        // Error encontrado: faltaba ';' en using System, en declaración string nombre, en int.Parse(...)
        // Tipo: sintaxis
        // Corrección: agregar punto y coma, completar declaraciones
        // Explicación: C# exige ; al final de cada instrucción simple.
    }

    static void Ejercicio2()
    {
        Console.WriteLine("--- Ejercicio 2 ---");
        double n1, n2, n3;
        Console.Write("Nota1: "); n1 = LeerDouble();
        Console.Write("Nota2: "); n2 = LeerDouble();
        Console.Write("Nota3: "); n3 = LeerDouble();
        // Error lógico: falta paréntesis -> nota1+nota2+nota3/3 da prioridad a división
        double prom = (n1 + n2 + n3) / 3;
        Console.WriteLine("Promedio: " + prom);
        // Error lógico: condición era >61, excluye 61; se cambia a >=61
        Console.WriteLine(prom >= 61 ? "Aprobó" : "Reprobó");
        // Explicación:fórmula sin paréntesis
        // y la condición incorrecta producían resultados erróneos sin aviso.
    }

    static void Ejercicio3()
    {
        Console.WriteLine("--- Ejercicio 3 ---");
        int[] nums = new int[5]; // índices 0..4
        int suma = 0;
        // Error ejecución: ciclo original i<=5 accedía a índice 5
        for (int i = 0; i < 5; i++)
        {
            Console.Write($"Número {i + 1}: ");
            nums[i] = LeerEntero();
            suma += nums[i];
        }
        Console.WriteLine("Suma total: " + suma);
        // Explicación: un arreglo[5] tiene posiciones 0-4; i=5
    }

    static void Ejercicio4()
    {
        Console.WriteLine("--- Ejercicio 4 ---");
        double b = LeerDimension("base");
        double h = LeerDimension("altura");
        // Error lógico: método original sumaba base+altura; se corrige a multiplicación
        double area = b * h;
        Console.WriteLine("Área: " + area);
        // Error lógico:excluía area=100; se corrige a >=100
        Console.WriteLine(area >= 100 ? "Grande" : "Pequeña");
        // Validaciones: se evitan valores <=0 y entradas no numéricas
    }

    static void Ejercicio5()
    {
        Console.WriteLine("--- Ejercicio 5 ---");
        int[] edades = new int[5];
        int suma = 0, mayores = 0;
        for (int i = 0; i < 5; i++) // corrección: i de 0 a 4 
        {
            Console.Write($"Edad persona {i + 1}: ");
            int edad = LeerEdadNoNegativa();
            edades[i] = edad;
            suma += edad;
            if (edad >= 18) mayores++; // corrección: >=18 
        }
        double prom = (double)suma / 5; // corrección: cast a double para división decimal
        Console.WriteLine("Promedio: " + prom);
        Console.WriteLine("Mayores de edad: " + mayores);

      
        // Error 1: ciclo for (int i=1; i<=5; i++) → acceso a edades[5] fuera de rango.
        // Error 2: condición if (edades[i] > 18) → excluye a los que tienen exactamente 18.
        // Error 3: promedio = suma/5 → división entera, pierde decimales.
        // Limitación: no validaba entradas no numéricas ni edades negativas.
        // Importancia validación humana: la IA produce código con errores lógicos y omisiones; el humano prueba casos límite y agrega robustez.
    }


    static double LeerDouble()
    {
        double v;
        while (!double.TryParse(Console.ReadLine(), out v))
            Console.Write("Inválido, ingrese número: ");
        return v;
    }

    static int LeerEntero()
    {
        int v;
        while (!int.TryParse(Console.ReadLine(), out v))
            Console.Write("Inválido, ingrese entero: ");
        return v;
    }

    static double LeerDimension(string nombre)
    {
        double v;
        do
        {
            Console.Write($"{nombre} (>0): ");
            while (!double.TryParse(Console.ReadLine(), out v))
                Console.Write($"Inválido, {nombre} (>0): ");
            if (v <= 0) Console.Write("Debe ser >0. ");
        } while (v <= 0);
        return v;
    }

    static int LeerEdadNoNegativa()
    {
        int v;
        do
        {
            while (!int.TryParse(Console.ReadLine(), out v))
                Console.Write("Inválido, ingrese entero: ");
            if (v < 0) Console.Write("No negativa: ");
        } while (v < 0);
        return v;
    }
}


// ¿Por qué una solución generada por IA debe ser revisada, probada y validada por una persona?
// 1. La IA puede cometer errores lógicos o de ejecución que no son evidentes.
// 2. No valida entradas ni maneja casos límite (edades negativas, texto, etc.).
// 3. Desconoce el contexto completo y los requisitos específicos del problema.
// 4. Puede generar código ineficiente o con malas prácticas.
// 5. La responsabilidad final del software recae en el desarrollador humano.
