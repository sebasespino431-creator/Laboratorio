﻿using System;

class Program
{
    static void Main()
    {
        

        
        Console.WriteLine("Ejercicio 1: Suma de dígitos");
        Console.Write("Ingrese un número entero positivo");
        int numero = int.Parse(Console.ReadLine());
        int resultadoSuma = SumaDigitos(numero);
        Console.WriteLine($"La suma de los dígitos de {numero} es: {resultadoSuma}");
        Console.WriteLine("Ejemplo de la tabla: 123 -> 6, 10905 -> 15\n");
        Console.WriteLine("Ejercicio 2: Elevar al cuadrado");
        Console.Write("Ingrese un número entero: ");
        int n = int.Parse(Console.ReadLine());
        Console.WriteLine($"Antes de la función: N = {n}");
        string mensaje = ElevarAlCuadrado(ref n);
        Console.WriteLine(mensaje);
        Console.WriteLine($"Después de la función: N = {n}");
        Console.WriteLine("Ejemplo de la tabla: N = 6 -> N = 36\n");
        Console.WriteLine("Ejercicio 3: Descuento en tienda");
        Console.Write("Ingrese el precio del producto: ");
        double precio = double.Parse(Console.ReadLine());
        Console.Write("Ingrese el porcentaje de descuento (ej. 0.25 para 25%): ");
        double descuento = double.Parse(Console.ReadLine());
        double montoDescontado = AplicarDescuento(ref precio, descuento);
        Console.WriteLine($"Precio final = {precio}, Descuento = {montoDescontado}");
        Console.WriteLine("Ejemplo de la tabla: Precio = 200, descuento = 0.25 -> Precio final = 150, Descuento = 50\n");
        Console.WriteLine("--- Ejercicio 4: Sistema de energía del jugador ---");
        int energiaJugador = 20;
        Console.WriteLine($"\nEnergía inicial: {energiaJugador}");
        Console.WriteLine($"Estado inicial: {obtenerEstado(energiaJugador)}");
        Console.WriteLine($"Rendimiento inicial: {calcularRendimiento(energiaJugador)}");
        Console.WriteLine("\n--- Probando consumirEnergia() ---");
        energiaJugador = consumirEnergia(ref energiaJugador);
        Console.WriteLine($"Después de consumir 4 unidades: {energiaJugador}");
        Console.WriteLine($"Estado: {obtenerEstado(energiaJugador)}");
        Console.WriteLine($"Rendimiento: {calcularRendimiento(energiaJugador)}");
        energiaJugador = consumirEnergia(ref energiaJugador);
        Console.WriteLine($"\nDespués de consumir otras 4 unidades: {energiaJugador}");
        Console.WriteLine($"Estado: {obtenerEstado(energiaJugador)}");
        Console.WriteLine($"Rendimiento: {calcularRendimiento(energiaJugador)}");
        Console.WriteLine("\n--- Probando recargarEnergia() ---");
        energiaJugador = recargarEnergia(ref energiaJugador);
        Console.WriteLine($"Después de recargar 6 unidades: {energiaJugador}");
        Console.WriteLine($"Estado: {obtenerEstado(energiaJugador)}");
        Console.WriteLine($"Rendimiento: {calcularRendimiento(energiaJugador)}");
        energiaJugador = recargarEnergia(ref energiaJugador);
        Console.WriteLine($"\nDespués de recargar otras 6 unidades: {energiaJugador}");
        Console.WriteLine($"Estado: {obtenerEstado(energiaJugador)}");
        Console.WriteLine($"Rendimiento: {calcularRendimiento(energiaJugador)}");
        Console.WriteLine("\n--- Prueba de límites (no menor a 0, no mayor a 20) ---");
        int energiaPrueba = 3;
        Console.WriteLine($"Energía inicial: {energiaPrueba}");
        energiaPrueba = consumirEnergia(ref energiaPrueba);
        Console.WriteLine($"Después de consumir 4 (debe ser 0): {energiaPrueba}");
        energiaPrueba = 18;
        Console.WriteLine($"\nEnergía inicial: {energiaPrueba}");
        energiaPrueba = recargarEnergia(ref energiaPrueba);
        Console.WriteLine($"Después de recargar 6 (debe ser 20): {energiaPrueba}");
    }

    static int SumaDigitos(int numero)
    {
        int suma = 0;
        numero = Math.Abs(numero); 

        while (numero > 0)
        {
            suma += numero % 10;  
            numero /= 10;         
        }

        return suma;
    }


    static string ElevarAlCuadrado(ref int numero)
    {
        numero = numero * numero;
        return "La operación fue realizada exitosamente.";
    }


    static double AplicarDescuento(ref double precio, double porcentajeDescuento)
    {
        double montoDescontado = precio * porcentajeDescuento;
        precio = precio - montoDescontado;
        return montoDescontado;
    }


    static int consumirEnergia(ref int energia)
    {
        energia -= 4;
        if (energia < 0)
        {
            energia = 0;
        }
        return energia;
    }

    static int recargarEnergia(ref int energia)
    {
        energia += 6;
        if (energia > 20)
        {
            energia = 20;
        }
        return energia;
    }

    static string obtenerEstado(int energia)
    {
        if (energia >= 15 && energia <= 20)
        {
            return "Alta";
        }
        else if (energia >= 8 && energia <= 14)
        {
            return "Media";
        }
        else
        {
            return "Baja";
        }
    }

 
    static string calcularRendimiento(int energia)
    {
        if (energia == 20)
        {
            return "S";
        }
        else if (energia >= 15 && energia <= 19)
        {
            return "A";
        }
        else if (energia >= 8 && energia <= 14)
        {
            return "B";
        }
        else
        {
            return "C";
        }
    }
}