﻿using System;

class Persona
{
    public string nombre;
    public int edad;
    public double altura;
    public bool estudiante;
}

class Vehiculo
{
    public string marca;
    public string modelo;
    public int anio;
    public string color;
    public string placa;
}

class Producto
{
    public string codigo;
    public string nombre;
    public double precio;
    public int stock;
    public bool disponible;
}

class Mascota
{
    public string nombre;
    public string especie;
    public int edad;
    public double peso;
    public bool vacunado;
}

class Program
{
    static void Main()
    {
     
        Persona persona1 = new Persona();
        persona1.nombre = "Angel Rios Mont";
        persona1.edad = 67;
        persona1.altura = 1.65;
        persona1.estudiante = true;

        Console.WriteLine("Nombre: " + persona1.nombre);
        Console.WriteLine("Edad: " + persona1.edad + " años");
        Console.WriteLine("Altura: " + persona1.altura + " m");
        Console.WriteLine("¿Estudiante?: " + persona1.estudiante);
        Console.WriteLine();

       
        Vehiculo miAuto = new Vehiculo();
        miAuto.marca = "Toyota";
        miAuto.modelo = "Corolla";
        miAuto.anio = 2020;
        miAuto.color = "Gris plata";
        miAuto.placa = "P-123ABC";

        Console.WriteLine("Marca: " + miAuto.marca);
        Console.WriteLine("Modelo: " + miAuto.modelo);
        Console.WriteLine("Año: " + miAuto.anio);
        Console.WriteLine("Color: " + miAuto.color);
        Console.WriteLine("Placa: " + miAuto.placa);
        Console.WriteLine();

    
        Producto producto1 = new Producto();
        producto1.codigo = "P001";
        producto1.nombre = "Laptop Gamer";
        producto1.precio = 8500.50;
        producto1.stock = 15;
        producto1.disponible = true;

        Producto producto2 = new Producto();
        producto2.codigo = "P002";
        producto2.nombre = "Mouse inalámbrico";
        producto2.precio = 250.00;
        producto2.stock = 0;
        producto2.disponible = false;

        Console.WriteLine("Producto 1 - Código: " + producto1.codigo + ", Nombre: " + producto1.nombre + ", Precio: Q" + producto1.precio + ", Stock: " + producto1.stock + ", Disponible: " + producto1.disponible);
        Console.WriteLine("Producto 2 - Código: " + producto2.codigo + ", Nombre: " + producto2.nombre + ", Precio: Q" + producto2.precio + ", Stock: " + producto2.stock + ", Disponible: " + producto2.disponible);
        Console.WriteLine();

   
        Mascota miMascota = new Mascota();
        miMascota.nombre = "Eli";
        miMascota.especie = "Perro";
        miMascota.edad = 3;
        miMascota.peso = 12.5;
        miMascota.vacunado = true;

        Console.WriteLine("Nombre: " + miMascota.nombre);
        Console.WriteLine("Especie: " + miMascota.especie);
        Console.WriteLine("Edad: " + miMascota.edad + " años");
        Console.WriteLine("Peso: " + miMascota.peso + " kg");
        Console.WriteLine("¿Vacunado?: " + miMascota.vacunado);
    }
}