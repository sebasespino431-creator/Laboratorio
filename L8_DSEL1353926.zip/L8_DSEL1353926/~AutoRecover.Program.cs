﻿using System;

class Program
{
    static void Main()
    {

        Console.WriteLine("1. Promedio de 10 estudiantes");
        Console.WriteLine("2. Contador de pares e impares");
        Console.WriteLine("3. Menu de tienda");
        Console.WriteLine("4. Modulo de numero hasta 0");
        Console.WriteLine("5. Contador hasta N");
        Console.Write("Opción: ");
        int opcion = int.Parse(Console.ReadLine());

        Console.Clear();

        switch (opcion)
        {
            case 1: Ejercicio1(); break;
            case 2: Ejercicio2(); break;
            case 3: Ejercicio3(); break;
            case 4: Ejercicio4(); break;
            case 5: Ejercicio5(); break;
            default: Console.WriteLine("Opción no válida."); break;
        }
    }

    static void Ejercicio1()
    {

        int nota, aprobado = 0, reprobado = 0, suma = 0;
        double promedio = 0;
        Console.WriteLine("Ejercicio#1");
        Console.WriteLine();
        for (int i = 0; i < 10; i++)
        {
            Console.WriteLine("Ingrese nota");
            nota = int.Parse(Console.ReadLine());
            if (nota <= 65)
            {
                aprobado++;
            }
            else
            {
                reprobado++;
            }
            suma = suma + nota;
        }
        promedio = suma / 10;
        Console.WriteLine();
        Console.WriteLine("Su promedio fue de: " + promedio);
        Console.WriteLine();
        Console.WriteLine("Los aprobados fueron: " + aprobado);
        Console.WriteLine();
        Console.WriteLine("Los reprobados fueron: " + reprobado);
        Console.WriteLine();
        Console.ReadKey();

    }

    static void Ejercicio2()
    {
            Console.Write("Ingrese un número entero: ");
            int n = Convert.ToInt32(Console.ReadLine());

            int suma = 0, pares = 0, impares = 0;

            for (int i = 1; i <= n; i++)
            {
                suma += i;

                if (i % 2 == 0)
                    pares++;
                else
                    impares++;
            }

            Console.WriteLine($"Suma total: {suma}");
            Console.WriteLine($"Números pares: {pares}");
            Console.WriteLine($"Números impares: {impares}");
            Console.ReadKey();



    }

    static void Ejercicio3()
    { 
            int opcion;
            double totalVentas = 0;
            int clientes = 0;

            do
            {
               
                Console.WriteLine("1) Registrar compra");
                Console.WriteLine("2) Mostrar total de ventas");
                Console.WriteLine("3) Mostrar cantidad de clientes atendidos");
                Console.WriteLine("4) Salir");
                Console.Write("Seleccione una opción: ");
                opcion = Convert.ToInt32(Console.ReadLine());

                switch (opcion)
                {
                    case 1:
                        Console.Write("Ingrese el monto de la compra: ");
                        double monto = Convert.ToDouble(Console.ReadLine());
                        totalVentas += monto;
                        clientes++;
                        Console.WriteLine("Compra registrada.");
                        break;

                    case 2:
                        Console.WriteLine($"Total de ventas del día: {totalVentas:F2}");
                        break;

                    case 3:
                        Console.WriteLine($"Clientes atendidos: {clientes}");
                        break;

                    case 4:
                        Console.WriteLine("Saliendo del programa...");
                        break;

                    default:
                        Console.WriteLine("Opción no válida. Intente de nuevo.");
                        break;
                }

            } while (opcion != 4);
        
    }


    static void Ejercicio4()
    {
       
    
       
            int numero;
            int totalNumeros = 0, positivos = 0, negativos = 0;
            int suma = 0;

            do
            {
                Console.Write("Ingrese un número (0 para salir): ");
                numero = Convert.ToInt32(Console.ReadLine());

                if (numero != 0)
                {
                    totalNumeros++;
                    suma += numero;

                    if (numero > 0)
                        positivos++;
                    else if (numero < 0)
                        negativos++;
                }

            } while (numero != 0);

            Console.WriteLine($"\nCantidad de números ingresados: {totalNumeros}");
            Console.WriteLine($"Números positivos: {positivos}");
            Console.WriteLine($"Números negativos: {negativos}");
            Console.WriteLine($"Suma total: {suma}");
        
    

}

    static void Ejercicio5()
    {
        

    
        
        
            Console.Write("Ingrese un número N: ");
            int n = Convert.ToInt32(Console.ReadLine());

            for (int i = 1; i <= n; i++)
            {
                for (int j = 1; j <= i; j++)
                {
                    Console.Write(j);
                }
                Console.WriteLine();
            }
        
    

}

}

